//
//  PerEditViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Peddi,Venkataramana on 8/28/23.
//

import UIKit

class PerEditViewController: UIViewController {

    var obj:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = obj.first
        // Do any additional setup after loading the view.
    }
    
 

}
