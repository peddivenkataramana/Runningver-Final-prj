//
//  PatientcatoViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Samala,Dhruva Teja on 6/1/23.
//

import UIKit

class PatientcatoViewController: UIViewController , UITableViewDataSource , UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return a.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = table.dequeueReusableCell(withIdentifier: "ab", for: indexPath)
            
            cell.textLabel?.text = a[indexPath.row]
            
            return cell
   
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let vcName = idet[indexPath.row]
        let viewController = (storyboard?.instantiateViewController(withIdentifier: vcName))!
        self.navigationController?.pushViewController(viewController , animated: true)
    }
    
        
    var a = ["View Reminders","Medicine History"]
    
     var idet = ["c","d"]
    
    @IBOutlet weak var table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        table.dataSource = self
        table.delegate = self
        // Do any additional setup after loading the view.
        
    }
    

    
 
}
