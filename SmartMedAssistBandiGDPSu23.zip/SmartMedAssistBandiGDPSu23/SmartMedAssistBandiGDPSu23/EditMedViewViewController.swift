//
//  EditMedViewViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Peddi,Venkataramana on 8/23/23.
//

import UIKit

class EditMedViewViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "friendCell", for: indexPath)
        
        cell.textLabel?.text = fd[indexPath.row]
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fd.count
    }
    
    
    
    
    
    var fd:[String] = ["a","b","c","d"]
    
    
    @IBOutlet weak var FrdT: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //FrdT.dataSource = self
        FrdT.delegate = self
        FrdT.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition  = segue.identifier
        if(transition == "edt"){
            ///set the destination
            
            var destination = segue.destination as! PerEditViewController
            
            destination.obj =   fd
            
        }
        
        
        
        
        
        
        
        
        
    }
}
    

