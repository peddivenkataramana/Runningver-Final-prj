//
//  PatientListViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Samala,Dhruva Teja on 6/1/23.
//

import UIKit

class PatientListViewController: UIViewController, UITableViewDataSource , UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1//a.count
    }
     
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       
        
            let cell = tablev.dequeueReusableCell(withIdentifier: "pt", for: indexPath)
            
            cell.textLabel?.text = "Patient 1"//a[indexPath.row]
            
            return cell
   
        
    }
     

    @IBOutlet weak var tablev: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        tablev.dataSource = self
        tablev.delegate = self
        // Do any additional setup after loading the view.
    }
    
 

}
