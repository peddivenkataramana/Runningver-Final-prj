//
//  CaretakerSigninViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Nelavelli,Chandu on 5/22/23.
//

import UIKit
import FirebaseAuth

class CaretakerSigninViewController: UIViewController {
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var Password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

         
        
        
        // Do any additional setup after loading the view.
    }
    func validateFields(){
        if Email.text?.isEmpty == true {
            print("No Email Text")
            return
        }
        
        if Password.text?.isEmpty == true{
            print("No Password")
            return
        }
        
        login()
    }
    
    func login(){
        Auth.auth().signIn(withEmail: Email.text!, password: Password.text!) { [weak self] authResult, err in
            guard let strongSelf = self else {return}
            if let err = err{
                print(err.localizedDescription)
                
                var dialogMessage = UIAlertController(title: "Alert!", message: err.localizedDescription, preferredStyle: .alert)
                
                // Create OK button with action handler
                let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                    print("Ok button tapped")
                })
                
                //Add OK button to a dialog message
                dialogMessage.addAction(ok)
                
                // Present Alert to
                self!.present(dialogMessage, animated: true, completion: nil)
                
                // self?.performSegue(withIdentifier:  "cat", sender: false)
                
            }
            
            else {
                //                let vc = self?.storyboard?.instantiateViewController(withIdentifier: "cat") as! CatogViewController
                //
                //                self?.navigationController?.pushViewController(vc,  animated: true)
                //
                //                self!.present(vc, animated: true, completion: nil)
                //
                //                print("login")
                
                var dialogMessage = UIAlertController(title: "Congrats!", message: "Successfully Login", preferredStyle: .alert)
                
                // Create OK button with action handler
                let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                    print("Ok button tapped")
                })
                
                //Add OK button to a dialog message
                dialogMessage.addAction(ok)
                
                // Present Alert to
                self!.present(dialogMessage, animated: true, completion: nil)
            }
        }
    }
    
    func checkUserInfo() {
        if Auth.auth().currentUser != nil {
            
            print(Auth.auth().currentUser?.uid)
            
            //            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            //            let vc = storyboard.instantiateViewController(withIdentifier: "cat")
            //            vc.modalPresentationStyle = .overFullScreen
            //            present(vc, animated: true)
        }
    }
    @IBAction func loginbtn(_ sender: Any) {
//        if(Email.text?.isEmpty == true || Password.text?.isEmpty == true){
//            var dialogMessage = UIAlertController(title: "Alert!", message: "Enter All Fileds.", preferredStyle: .alert)
//
//            // Create OK button with action handler
//            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
//                print("Ok button tapped")
//             })
//
//            //Add OK button to a dialog message
//            dialogMessage.addAction(ok)
//
//            // Present Alert to
//            self.present(dialogMessage, animated: true, completion: nil)
//        }
        
        validateFields()
        
    }
    
    
    
    func showAlertMsg(message:String){
        // Create new Alert
        var dialogMessage = UIAlertController(title: "Alert!", message: message, preferredStyle: .alert)
        
        // Create OK button with action handler
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("Ok button tapped")
        })
        
        //Add OK button to a dialog message
        dialogMessage.addAction(ok)
        
        // Present Alert to
        self.present(dialogMessage, animated: true, completion: nil)
    }

}
