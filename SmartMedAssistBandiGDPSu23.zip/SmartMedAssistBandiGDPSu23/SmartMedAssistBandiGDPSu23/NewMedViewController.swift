//
//  NewMedViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Nelavelli,Chandu on 5/30/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class NewMedViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {
    
     
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return days.count
    }
    
    func pickerView(_ pickerView: UIPickerView,titleForRow row :Int,forComponent component : Int) -> String?
    {
        return days[row]
    }
    func numberOfComponents(in picker: UIPickerView) -> Int
    {
        return 1
    }
    
      func pickerView(_ pickerView: UIPickerView,didSelectRow row:Int,inComponent component:Int)
    
    {
        day.text = days[row]
        day.resignFirstResponder()
    }
    
    
 
    
    @IBOutlet weak var count: UITextField!

    @IBOutlet weak var medname: UITextField!
    
    
    @IBOutlet weak var startdate: UITextField!
    
    
    
    @IBOutlet weak var enddate: UITextField!
    
    @IBOutlet weak var time: UITextField!
    
    @IBOutlet weak var day: UITextField!
     
    
    @IBOutlet weak var snooz: UITextField!
    
    
    let timePicker = UIDatePicker()
 
    let datepicker = UIDatePicker()
    let pickerView = UIPickerView()
    let pickerView1 = UIPickerView()
    let datep = UIDatePicker()
    
    let days = ["EveryDay","Monday","Tuesday","Wednesday","Thrusday","Friday","Saturday","Sunday"]
    
    var a : String = "Before Food"
   
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView1.delegate = self
        pickerView1.dataSource = self
        day.inputView = pickerView
        
        
        
         createdate()
        createdate1()
        createtime()
        
        }
    
 
     
    
    
    @IBAction func switchfuc(_ sender: UISegmentedControl) {
        
        if(sender.selectedSegmentIndex == 0 )
        {
            a = "Before Food"
            print(a)
        }
        else{
            a = "After Food"
            
        }
    }
    
    
    func createtime(){
//       let timet = Date()
//        let formatter  = DateFormatter()
//        formatter.locale = Locale(identifier: "en_gb")
//        formatter.dateFormat = "HH:mm:ss"
//        time.text = formatter.string(from: timet)
//
//
//        timePicker.datePickerMode = .time
//        timePicker.addTarget(self, action: #selector(timePickerValueChanged(sender:)), for: UIControl.Event.valueChanged)
//        timePicker.frame.size = CGSize(width: 0, height: 250)
//        time.inputView = timePicker
        
        
        let toolbar = UIToolbar()
        
        toolbar.sizeToFit()
        
        let doneButton  = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(done))
        
        toolbar.items = [doneButton]
        time.inputAccessoryView = toolbar
        time.inputView = timePicker
        timePicker.datePickerMode = .time
        timePicker.frame.size = CGSize(width: 0, height: 250)
    }
    
    
    @objc func done(){
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        
        time.text =  formatter.string(from: timePicker.date)
        self.view.endEditing(true)
    }
    
    
    
    
    
    
    
    
    
    
//    @objc func  timePickerValueChanged(sender: UIDatePicker)
//    {
//        let formatter = DateFormatter()
//        formatter.locale = Locale(identifier: "en_gb")
//        formatter.dateFormat = "HH:mm:ss"
//        time.text =  formatter.string(from: sender.date)
//    }
    
    
    
    
    
    
    
    
    
    
    
    func createdate(){
        
        datepicker.datePickerMode = .date
        datepicker.frame.size = CGSize(width: 0, height: 300)
        
        datepicker.preferredDatePickerStyle = .inline
        
        startdate.inputView = datepicker
         
        
        
        let toolbar = UIToolbar()
        
        toolbar.sizeToFit()
        
        let doneButton  = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneClicked))
        
        toolbar.setItems([doneButton], animated: true)
        startdate.inputAccessoryView = toolbar
         
        
    }
    
    
    func createdate1(){
         datep.datePickerMode = .date
        enddate.inputView = datep
        datep.frame.size = CGSize(width: 0, height: 300)
        
        datep.preferredDatePickerStyle = .inline
        
        
        let toolbar = UIToolbar()
        
        toolbar.sizeToFit()
        
        let doneButton  = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneClicked1))
        
        toolbar.setItems([doneButton], animated: true)
    enddate.inputAccessoryView = toolbar
    }
    
    
    @objc func doneClicked1(){
        let dateFormatter  = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
    
        enddate.text = dateFormatter.string(from: datep.date)
        self.view.endEditing(true)
        
    }
    
    
    
    
    @objc func doneClicked(){
        let dateFormatter  = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        
        startdate.text = dateFormatter.string(from: datepicker.date)
        self.view.endEditing(true)
         
        
    }
    
    @IBAction func add(_ sender: Any) {
        if(medname.text?.isEmpty == true || startdate.text?.isEmpty == true || enddate.text?.isEmpty == true || count.text?.isEmpty == true || time.text?.isEmpty == true || day.text?.isEmpty == true || snooz.text?.isEmpty == true )
        {
            var dialogMessage = UIAlertController(title: "Alert!", message: "Please Enter All Fileds", preferredStyle: .alert)
            
            // Create OK button with action handler
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
            })
            
            //Add OK button to a dialog message
            dialogMessage.addAction(ok)
            
            // Present Alert to
            self.present(dialogMessage, animated: true, completion: nil)
        }
        else{
            var dialogMessage = UIAlertController(title: "Congrats!", message: "Medicine Detalis Successfully Added  ", preferredStyle: .alert)
            
            // Create OK button with action handler
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
            })
            
            //Add OK button to a dialog message
            dialogMessage.addAction(ok)
            
            // Present Alert to
            self.present(dialogMessage, animated: true, completion: nil)
            self.addmedicine()
            performSegue(withIdentifier: "cat", sender: nil)
        }
       
        
        
        
        
    }
    func addmedicine(){
        let user = Auth.auth().currentUser
        if let user = user {
            // The user's ID, unique to the Firebase project.
            // Do NOT use this value to authenticate with your backend server,
            // if you have one. Use getTokenWithCompletion:completion: instead.
            let userId = user.uid
            var medicine: [String:Any] = [
                "medicine_name" : medname.text!,
                "start_date" : startdate.text!,
                "end_date" : enddate.text!,
                "medicine_count" : count.text!,
                "meal_preference" : a,
                "time" : time.text!,
                "days" : day.text!,
                "snooze" : snooz.text!,
                
            ]
            Firestore.firestore().collection("patient").document(userId).setData(["medicines":[medname.text!:medicine],] , merge: true)
        }
    }

}
