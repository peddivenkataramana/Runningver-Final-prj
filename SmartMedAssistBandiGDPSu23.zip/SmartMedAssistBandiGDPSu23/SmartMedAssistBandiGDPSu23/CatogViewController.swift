//
//  CatogViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Nelavelli,Chandu on 5/24/23.
//

import UIKit

class CatogViewController: UIViewController , UITableViewDataSource , UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return a.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       
        
            let cell = table.dequeueReusableCell(withIdentifier: "a", for: indexPath)
            
            cell.textLabel?.text = a[indexPath.row]
            
            return cell
   
        
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let vcName = idet[indexPath.row]
        let viewController = (storyboard?.instantiateViewController(withIdentifier: vcName))!
        self.navigationController?.pushViewController(viewController , animated: true)
    }
    
        
    var a = ["New Medicine Details","Edit Reminders","View Reminders","Medicine History","Health Reports"]
    
     var idet = ["a","b","c","d","e"]
    
    @IBOutlet weak var table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        table.dataSource = self
        table.delegate = self
 
        // Do any additional setup after loading the view.
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
