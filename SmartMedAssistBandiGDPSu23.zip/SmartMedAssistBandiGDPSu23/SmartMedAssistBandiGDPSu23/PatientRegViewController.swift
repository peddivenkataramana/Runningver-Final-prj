//
//  PatientRegViewController.swift
//  SmartMedAssistBandiGDPSu23
//
//  Created by Nelavelli,Chandu on 5/22/23.
//

import UIKit
import FirebaseAuth
import Firebase
import FirebaseFirestore

class PatientRegViewController: UIViewController {
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var Emailid: UITextField!
    
    @IBOutlet weak var CreatePassword: UITextField!
    
    @IBOutlet weak var ConformPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Signup(_ sender: Any) {
        if(name.text?.isEmpty == true || Emailid.text?.isEmpty == true || CreatePassword.text?.isEmpty == true || ConformPassword.text?.isEmpty == true){
            
            
            
            
            
            var dialogMessage = UIAlertController(title: "Alert!", message: "Enter All Fileds.", preferredStyle: .alert)
            
            // Create OK button with action handler
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
            })
            
            //Add OK button to a dialog message
            dialogMessage.addAction(ok)
            
            // Present Alert to
            self.present(dialogMessage, animated: true, completion: nil)
            
            
            
            
            
            
        }
        
        
        else if(CreatePassword.text != ConformPassword.text){
            
            
            var dialogMessage = UIAlertController(title: "Alert!", message: "CONFORM PASSWORD MISMATCH.", preferredStyle: .alert)
            
            // Create OK button with action handler
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
            })
            
            //Add OK button to a dialog message
            dialogMessage.addAction(ok)
            
            // Present Alert to
            self.present(dialogMessage, animated: true, completion: nil)
        }
        else
        {
            signup()
        }
        
        
    }
    
    func signup()
    {
        
        Auth.auth().createUser(withEmail: Emailid.text!, password: ConformPassword.text!){(authResult,error) in
            guard let user = authResult?.user, error == nil else{
                print("Error \(error?.localizedDescription)")
                
                
                
                if(error?.localizedDescription.isEmpty == false){
                    var dialogMessage = UIAlertController(title: "Alter!", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    // Create OK button with action handler
                    let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                        print("Ok button tapped")
                    })
                    
                    
                    //Add OK button to a dialog message
                    dialogMessage.addAction(ok)
                    
                    // Present Alert to
                    self.present(dialogMessage, animated: true, completion: nil)
                    
                }
                return
            }
            
            
            self.createProfile()
            
            var dialogMessage = UIAlertController(  title: "Congratulations!", message: "You have Successfully Signed Up.", preferredStyle: .alert)
            
            
            // Create OK button with action handler
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
              //  self.performSegue(withIdentifier: "gotosegue", sender: nil)
            })
            
            //Add OK button to a dialog message
            dialogMessage.addAction(ok)
            
            // Present Alert to
            self.present(dialogMessage, animated: true, completion: nil)
            
            
//
//            let storyboard  = self.storyboard?.instantiateViewController(identifier: "PatientSigninViewController") as! PatientSigninViewController
//            self.navigationController?.pushViewController(storyboard, animated: true)
            
            
        }
        
    }
    func createProfile(){
        let user = Auth.auth().currentUser
        if let user = user {
            // The user's ID, unique to the Firebase project.
            // Do NOT use this value to authenticate with your backend server,
            // if you have one. Use getTokenWithCompletion:completion: instead.
            let userId = user.uid
            var userData: [String:Any] = [
                "userid" : user.uid,
                "name" : name.text!,
                "email" : Emailid.text!,
                "date_created" : Timestamp(),
            ]
            if let photoUrl = user.photoURL{
                userData["photo_url"] = photoUrl
            }
            
            Firestore.firestore().collection("patient").document(userId).setData(userData, merge: false)
        }
    }
    
}
